<?php 
include_once  dirname( dirname( dirname(__FILE__) ) ) . '/tools/php/lsdir.php';
listFolderFiles('.'); 
?>
